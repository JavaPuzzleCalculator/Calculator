#!/bin/bash

java -jar ./code/PuzzleCalculator.jar