#!/usr/bin/env bash

java -jar ./code/PuzzleCalculator.jar